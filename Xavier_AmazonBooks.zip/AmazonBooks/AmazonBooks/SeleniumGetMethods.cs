﻿using System;
using OpenQA.Selenium;
using System.Collections.Generic;

namespace AmazonBooks
{
    class SeleniumGetMethods
    {
        public static string GetItemTitle(IWebElement element)
        {
            return element.Text;
        }
        public static string GetItemType( IWebElement element)
        {
            return element.Text;
        }

        public static string GetItemPrice(IWebElement element)
        {
            return element.Text;
        }

        public static string GetItemAddedToBasket(IWebElement element)
        {
            return element.Text;
        }

        public static string GetItemQuantity(IWebElement element)
        {
            return element.Text;
        }

        public static string GetItemSubtotal(IWebElement element)
        {
            return element.Text;
        }
    }
}
