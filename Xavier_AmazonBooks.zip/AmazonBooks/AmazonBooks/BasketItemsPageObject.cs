﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;


namespace AmazonBooks
{
    class BasketItemsPageObject
    {
        public BasketItemsPageObject()
        {
            PageFactory.InitElements(PropertiesCollection.driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='huc - v2 - order - row - confirm - text']/h1")]
        public IWebElement lblAddedToBasket { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='hlb-subcart']/div[1]/span/span[1]/text()")]
        public IWebElement lblItemsInBasket { get; set; }

        [FindsBy(How = How.Id, Using = "hlb-view-cart-announce")]
        public IWebElement btnEditBasket { get; set; }

        public void VerifyBusketItems()
        {
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemAddedToBasket(lblAddedToBasket), "Added to Basket");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemAddedToBasket(lblItemsInBasket), "(1 item):");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        public EditBasketPageObject EditBasketItems()
        {
            SeleniumSetMethods.Click(btnEditBasket);
            return new EditBasketPageObject();
        }

    }
}
