﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace AmazonBooks
{
    class Program
    {
       
        static void Main(string[] args)
        {
        }

        [SetUp]
        public void Initialize()
        {
            try
            {
                String expectedUrl = "https://www.amazon.co.uk/";
                PropertiesCollection.driver = new ChromeDriver();
                PropertiesCollection.driver.Navigate().GoToUrl(expectedUrl);

                Assert.AreEqual(expectedUrl, PropertiesCollection.driver.Url);
                Console.WriteLine("Navigated to correct webpage"); 
            }
            catch (Exception pageNavigationError)
            {
                Console.WriteLine("Didn't navigate to correct webpage:{0}",pageNavigationError.Message); 
            }
        }

        [Test]
        public void ExecuteTest()
        {
            try
            {
                ItemsListPageObject pageItemsList = new ItemsListPageObject();
                pageItemsList.SearchBooks("Game of Thrones", "Books");
                pageItemsList.VerifyItemDetails();
                pageItemsList.ItemClick();


                ItemDetailsPageObject pageItemDetails = new ItemDetailsPageObject();
                pageItemDetails.VerifyItemDetails();
                pageItemDetails.AddToBasket();

                BasketItemsPageObject pageItemsInBasket = new BasketItemsPageObject();
                pageItemsInBasket.VerifyBusketItems();
                pageItemsInBasket.EditBasketItems();

                EditBasketPageObject pageEditItemsInBasket = new EditBasketPageObject();
                pageEditItemsInBasket.VerifyItemDetails();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }

        }
        [TearDown]
        public void CleanUp()
        {
            PropertiesCollection.driver.Close();
        }
    }
}
