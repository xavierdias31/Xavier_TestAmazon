﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace AmazonBooks
{
    class ItemDetailsPageObject
    {
        public ItemDetailsPageObject()
        {
            PageFactory.InitElements(PropertiesCollection.driver,this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='productTitle']")]
        public IWebElement ItemTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='title']/span[2]")]
        public IWebElement ItemType { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='a - autoid - 4 - announce']/span[2]/span")]
        public IWebElement ItemPrice { get; set; }
        
        [FindsBy(How = How.Id, Using = "add-to-cart-button")]
        public IWebElement btnAddToBasket { get; set; }

        public void VerifyItemDetails()
        {
            try
            {
                //no "best seller" badge info
                Assert.AreEqual(SeleniumGetMethods.GetItemTitle(ItemTitle), "A Game of Thrones(A Song of Ice and Fire, Book 1)");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}",e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemType(ItemType), "Paperback");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemPrice(ItemPrice), "£4.00");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        public BasketItemsPageObject AddToBasket()
        {
            SeleniumSetMethods.AddToCart(btnAddToBasket);
            return new BasketItemsPageObject();
        }
    }
}
