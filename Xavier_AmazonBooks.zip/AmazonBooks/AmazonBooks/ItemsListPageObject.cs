﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;

namespace AmazonBooks
{

    class ItemsListPageObject
    {
        public ItemsListPageObject()
        {
            PageFactory.InitElements(PropertiesCollection.driver,this);
        }

        [FindsBy(How=How.Id,Using = "searchDropdownBox")]
        public IWebElement ddSearchBooks { get; set; }

        [FindsBy(How = How.Name, Using = "field-keywords")]
        public IWebElement txtSearchKeyWord { get; set; }

        [FindsBy(How=How.XPath,Using = "//*[@id='result_0']/div/div/div/div[2]/div[1]/div[1]/a/h2")]
        public IWebElement  ItemTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='result_0']/div/div/div/div[2]/div[2]/div[1]/div[1]/a/h3")]
        public IWebElement ItemType { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='result_0']/div/div/div/div[2]/div[2]/div[1]/div[2]/a/span[2]")]
        public IWebElement ItemPrice { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='result_0']/div/div/div/div[1]/div/div/a/img")]
        public IWebElement ClickItem { get; set; }

        public void SearchBooks(string title,string department)
        {
            try
            {
                SeleniumSetMethods.SelectDropDown(ddSearchBooks, department);
                SeleniumSetMethods.EnterText(txtSearchKeyWord, title);
                SeleniumSetMethods.SubmitRequest(txtSearchKeyWord);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }
        public void VerifyItemDetails()
        {
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemTitle(ItemTitle), "A Game of Thrones(A Song of Ice and Fire, Book 1)");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemType(ItemType), "Paperback");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemPrice(ItemPrice), "£4.00");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        public ItemDetailsPageObject ItemClick()
        {
            SeleniumSetMethods.Click(ClickItem);
           return new ItemDetailsPageObject();
        }

    }
}
