﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;


namespace AmazonBooks
{
    class EditBasketPageObject
    {
        public EditBasketPageObject()
        {
            PageFactory.InitElements(PropertiesCollection.driver, this);
        }

        [FindsBy(How = How.XPath, Using = "//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[1]/div/div/div[2]/ul/li[1]/span/a/span")]
        public IWebElement ItemTitle { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[1]/div/div/div[2]/ul/li[2]/span/span")]
        public IWebElement ItemType { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='activeCartViewForm']/div[2]/div/div[4]/div/div[2]/p/span")]
        public IWebElement ItemPrice { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='a - autoid - 2 - announce']/span[2]")]
        public IWebElement ItemQuantity { get; set; }

        [FindsBy(How = How.XPath, Using = "//*[@id='sc - subtotal - amount - activecart']/span")]
        public IWebElement ItemSubtotal { get; set; }

        public void VerifyItemDetails()
        {
            try
            {
                //no "best seller" badge info
                Assert.AreEqual(SeleniumGetMethods.GetItemTitle(ItemTitle), "A Game of Thrones(A Song of Ice and Fire, Book 1)");
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }

            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemType(ItemType), "Paperback");
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemPrice(ItemPrice), "£4.00");
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemQuantity(ItemQuantity), "1");
                
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
            try
            {
                Assert.AreEqual(SeleniumGetMethods.GetItemSubtotal(ItemSubtotal), "£4.00");
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }

        }

    }
}
